package com.comp301.a04junit.adventure;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 * should write tests for. You are not required to implement this class yourself. See the readme for
 * instructions on what this class is supposed to do.
 */
public class PlayerImpl implements Player {
  private String name;
  private Inventory inventory;
  private Position position;

  public PlayerImpl(String name, int startX, int startY) {
    // CODE OMITTED
  }

  public String getName() {
    return null; // CODE OMITTED
  }

  @Override
  public Position getPosition() {
    return null; // CODE OMITTED
  }

  @Override
  public Inventory getInventory() {
    return null; // CODE OMITTED
  }

  @Override
  public void move(Direction direction) {
    // CODE OMITTED
  }
}
