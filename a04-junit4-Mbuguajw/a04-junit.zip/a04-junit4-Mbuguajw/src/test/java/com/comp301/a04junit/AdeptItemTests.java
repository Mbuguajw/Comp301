package com.comp301.a04junit;

import static org.junit.Assert.assertTrue;

import com.comp301.a04junit.adventure.Item;
import com.comp301.a04junit.adventure.ItemImpl;

import org.junit.Test;

/** Write unit tests for the ItemImpl class here */
public class  AdeptItemTests {
  @Test
  public void itemConstructorTest() {
    Item tool = new ItemImpl("Pen");
    assertTrue(!(tool != new ItemImpl("Pen")));
  }

  @Test
  public void getNameTest() {
    Item tool = new ItemImpl("Pen");
    assertTrue(tool.getName() == "Pen");
  }

  @Test
  public void equalsTest() {
    Item tool = new ItemImpl("Pen");
    Item utensil = new ItemImpl("Pen");
    assertTrue(tool.getName() == utensil.getName());
  }

  @Test
  public void toStringTest() {
    Item tool = new ItemImpl("Pen");
    assertTrue(tool.toString() == "Pen");
  }
}
