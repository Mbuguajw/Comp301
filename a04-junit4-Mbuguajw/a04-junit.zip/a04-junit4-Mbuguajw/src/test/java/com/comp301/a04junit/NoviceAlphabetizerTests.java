package com.comp301.a04junit;

import static org.junit.Assert.assertTrue;

import com.comp301.a04junit.alphabetizer.Alphabetizer;

import java.util.ArrayList;
import org.junit.Test;

/** Write tests for the Alphabetizer class here */
public class NoviceAlphabetizerTests {
  @Test
  public void alphaConstructorTest() {
    String[] alpha = new String[4];
    alpha[3] = "a";
    alpha[2] = "b";
    alpha[0] = "c";
    alpha[1] = "d";
    Alphabetizer abc = new Alphabetizer(alpha);
    assertTrue(alpha[3] == "d" && alpha[2] == "c" && alpha[1] == "b" && alpha[0] == "a");
  }

  @Test
  public void nextTest() {
    String[] alpha = new String[4];
    alpha[3] = "a";
    alpha[2] = "b";
    alpha[0] = "c";
    alpha[1] = "d";
    Alphabetizer abc = new Alphabetizer(alpha);
    assertTrue(alpha.next() == "b" && alpha.next() == "c" && alpha.next() == "d");
  }

  @Test
  public void hasNextTest() {
    String[] alpha = new String[4];
    alpha[3] = "a";
    alpha[2] = "b";
    alpha[0] = "c";
    alpha[1] = "d";
    Alphabetizer abc = new Alphabetizer(alpha);
    assertTrue(alpha.hasNext() && alpha.hasNext() && !alpha.hasNext());
  }
}
