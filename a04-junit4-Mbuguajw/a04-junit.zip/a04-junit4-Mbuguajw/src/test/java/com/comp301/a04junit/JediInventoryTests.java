package com.comp301.a04junit;

import static org.junit.Assert.assertTrue;

import com.comp301.a04junit.adventure.Item;
import com.comp301.a04junit.adventure.ItemImpl;
import com.comp301.a04junit.adventure.Inventory;
import com.comp301.a04junit.adventure.InventoryImpl;

import org.junit.Test;

/** Write unit tests for the InventoryImpl class here */
public class JediInventoryTests {
  @Test
  public void inventConstructorTest() {
    InventoryImpl backpack = new InventoryImpl();
    assertTrue(backpack.isEmpty() && backpack == new InventoryImpl());
  }

  @Test
  public void isEmptyTest() {
    InventoryImpl backpack = new InventoryImpl();
    ItemImpl one = new ItemImpl("pen");
    ItemImpl two = new ItemImpl("marker");
    ItemImpl three = new ItemImpl("pencil");
    ItemImpl four = new ItemImpl("crayon");
    backpack.addItem(one);
    backpack.addItem(two);
    backpack.addItem(three);
    backpack.addItem(four);
    assertTrue(true); // TODO: Write your first unit test!
  }

  @Test
  public void getItemsTest() {
    InventoryImpl backpack = new InventoryImpl();
    ItemImpl one = new ItemImpl("pen");
    ItemImpl two = new ItemImpl("marker");
    ItemImpl three = new ItemImpl("pencil");
    ItemImpl four = new ItemImpl("crayon");
    backpack.addItem(one);
    backpack.addItem(two);
    backpack.addItem(three);
    backpack.addItem(four);
    assertTrue(true); // TODO: Write your first unit test!
  }
  @Test
  public void getNumItemsTest() {
    InventoryImpl backpack = new InventoryImpl();
    ItemImpl one = new ItemImpl("pen");
    ItemImpl two = new ItemImpl("marker");
    ItemImpl three = new ItemImpl("pencil");
    ItemImpl four = new ItemImpl("crayon");
    backpack.addItem(one);
    backpack.addItem(two);
    backpack.addItem(three);
    backpack.addItem(four);
    assertTrue(true); // TODO: Write your first unit test!
  }

  @Test
  public void getNumItemsTest() {
    InventoryImpl backpack = new InventoryImpl();
    ItemImpl one = new ItemImpl("pen");
    ItemImpl two = new ItemImpl("marker");
    ItemImpl three = new ItemImpl("pencil");
    ItemImpl four = new ItemImpl("crayon");
    backpack.addItem(one);
    backpack.addItem(two);
    backpack.addItem(three);
    backpack.addItem(four);
    assertTrue(true); // TODO: Write your first unit test!
  }
}
