package com.comp301.a04junit;

import static org.junit.Assert.assertTrue;

import com.comp301.a04junit.adventure.Direction;
import com.comp301.a04junit.adventure.Position;
import com.comp301.a04junit.adventure.PositionImpl;

import org.junit.Test;

/** Write unit tests for the PositionImpl class here */
public class AdeptPositionTests {
  @Test
  public void positionConstructorTest() {
    Position origin = new PositionImpl(0, 0);
    assertTrue(origin.getX() == 0 && origin.getY() == 0);
  }

  @Test
  public void getXTest() {
    Position origin = new PositionImpl(0, 0);
    Position square = new PositionImpl(5, 2);
    Position away = new PositionImpl(-7, 4);
    assertTrue(origin.getX() == 0 && square.getX() == 5 && away.getX() == -7);
  }

  @Test
  public void getYTest() {
    Position origin = new PositionImpl(0, 0);
    Position square = new PositionImpl(5, 2);
    Position away = new PositionImpl(-7, 4);
    assertTrue(origin.getY() == 0 && square.getY() == 2 && away.getY() == 4);
  }

  @Test
  public void getNeighborTest() {
    Position origin = new PositionImpl(0, 0);
    Position north = new PositionImpl(1, 0);
    Position south = new PositionImpl(-1, 0);
    Position east = new PositionImpl(0, 1);
    Position west = new PositionImpl(0, -1);

    assertTrue(origin.getNeighbor(Direction.NORTH) == north && origin.getNeighbor(Direction.SOUTH) == south && origin.getNeighbor(Direction.EAST) == east && origin.getNeighbor(Direction.WEST) == west);
  }
}
