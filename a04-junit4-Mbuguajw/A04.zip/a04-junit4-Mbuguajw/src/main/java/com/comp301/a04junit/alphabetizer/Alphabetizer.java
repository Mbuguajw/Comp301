package com.comp301.a04junit.alphabetizer;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 * should write tests for. You are not required to implement this class yourself. See the readme for
 * instructions on what this class is supposed to do.
 */
public class Alphabetizer {
  private String[] sorted;
  private int n;

  public Alphabetizer(String[] arr) {
    // CODE OMITTED
  }

  public String next() {
    return null; // CODE OMITTED
  }

  public boolean hasNext() {
    return false; // CODE OMITTED
  }
}
